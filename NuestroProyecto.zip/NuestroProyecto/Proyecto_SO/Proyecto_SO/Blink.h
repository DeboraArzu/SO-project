#pragma once

class Blink
{
public:
	Blink(void);
	~Blink(void);
};
