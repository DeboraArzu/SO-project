#include "StdAfx.h"
#include "z:\Pruebas2\Pruebas2\Pruebas2\mouse.h"
#include "mouse.h"

mouse::mouse(void)
{
}

mouse::~mouse(void)
{
}

mouse::mouse(void)
{
}

mouse::~mouse(void)
{
}
