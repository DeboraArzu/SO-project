﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NetworkCommsDotNet;
using NetworkCommsDotNet.Connections;
using System.Threading;


namespace ChatParcial
{
    class logic
    {
        

        static String returnMessage(String mssg)
        {
            return mssg;
        }
    }
}
