﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NetworkCommsDotNet;
using NetworkCommsDotNet.Connections;
using System.Threading;
using System.Collections;
using System.IO;
using System.Diagnostics;
using System.IO.Ports;
using System.Net.NetworkInformation;

namespace ChatParcial
{
    public partial class Form1 : Form
    {
        int NumeroParticipantes = 0;
        String[] serverIP= new String[3];
        int connected = 0;
        int[] serverPort=new int[3];
        int[] Puertos;
        int numeroPuertos=0;
        String[] ListConnected = new String[3];
       
        public Form1()
        {
            InitializeComponent();
            server();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            sendMessage(tbCommand.Text);
        }

        void sendMessage(String Message)
        {
            rtbChat.AppendText("Me: " + Message + "\n");
            //Send the message in a single line
            try
            {
                for(int i = 0; i < NumeroParticipantes; i++)
                {
                    NetworkComms.SendObject("Message", serverIP[i], serverPort[i], Message);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Error");
            }
        }

        void showMessage(String message)
        {
            if (rtbChat.InvokeRequired)
            {
                rtbChat.Invoke(new MethodInvoker(delegate { rtbChat.AppendText(message); }));
            }

           
        }

         void client(String serverInfo)
        {
            
            serverIP[NumeroParticipantes] = serverInfo.Split(':').First();
            serverPort[NumeroParticipantes] = int.Parse(serverInfo.Split(':').Last());

            
        }

         void server()
        {
            //Trigger the method PrintIncomingMessage when a packet of type 'Message' is received
            //We expect the incoming object to be a string which we state explicitly by using <string>
            NetworkComms.AppendGlobalIncomingPacketHandler<string>("Message", PrintIncomingMessage);
            //Start listening for incoming connections
            Connection.StartListening(ConnectionType.TCP, new System.Net.IPEndPoint(System.Net.IPAddress.Any, 0));

            //Print out the IPs and ports we are now listening on
            
            foreach (System.Net.IPEndPoint localEndPoint in Connection.ExistingLocalListenEndPoints(ConnectionType.TCP))
                rtbChat.AppendText(localEndPoint.Address + ":" + localEndPoint.Port + "\n"); 
        }

        /// <summary>
                /// Writes the provided message to the console window
                /// </summary>
                /// <param name="header">The packet header associated with the incoming message</param>
                /// <param name="connection">The connection used by the incoming message</param>
                /// <param name="message">The message to be printed to the console</param>
        
        private  void PrintIncomingMessage(PacketHeader header, Connection connection, string message)
        {

            try
            {
                VerificarListConnected(connection.ToString());
                if (message.Equals("dir"))
                {
                    String dir="";
                    string[] lista = System.IO.Directory.GetFiles("c:\\");
                    foreach (String s in lista)
                    {
                        dir += s;
                    }
                    for(int i = 0; i < NumeroParticipantes; i++)
                    {
                        NetworkComms.SendObject("Message", serverIP[i], serverPort[i], dir);
                    }
                    //validar mediante un for la posicion y a que computadora lo solicito
                }else if (message.Equals("list"))
                {
                
                    showMessage(connection.ToString());
                }
            }
            catch (Exception e)
            {

            }

            String result = "\n" + connection.ToString() + " said " + message + "." + "\n";
            showMessage(result);

        }

        private void btnConPort_Click(object sender, EventArgs e)
        {
            //Jalo los datos de la conexion
            client(tbConnect.Text);
            NumeroParticipantes++;
            MessageBox.Show("Connected");
            tbConnect.Text = "";
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        static void ListaPuertos(ref ArrayList usePort)
        {
            /* "Cos este ccodigo llamas a la funcion ListaPuertos"
             * ArrayList usePort = new ArrayList();
             * ListaPuertos(ref usePort);
             * Console.ReadKey();
             */

            IPGlobalProperties TCPConect = IPGlobalProperties.GetIPGlobalProperties();
            TcpConnectionInformation[] tcpconection = TCPConect.GetActiveTcpConnections();
            IEnumerator num = tcpconection.GetEnumerator();
            while (num.MoveNext())
            {
                TcpConnectionInformation TCPInfo = (TcpConnectionInformation)num.Current;
                //Console.WriteLine("Port {0} {1} {2}", TCPInfo.LocalEndPoint, TCPInfo.RemoteEndPoint, TCPInfo.State);
                usePort.Add(TCPInfo.LocalEndPoint.Port);
            }
        }
        String ListaParticipantes;
        private void button1_Click(object sender, EventArgs e)
        { 
            foreach(String s in serverIP)
            {
                ListaParticipantes += "\n"+ s;
            }
            MessageBox.Show(ListaParticipantes);
        }

        private void button2_Click(object sender, EventArgs e)
        {//elimina la ip del equipo a expulsar
            sendMessage("El participante" + textBox1.Text + " ha sido retirado de la conversacion");
            for (int i = 0; i < NumeroParticipantes; i++)
            {
                if (serverIP[i] == textBox1.Text)
                {
                    serverIP[i] = "" ;
                    serverPort[i] = 0;
                    //realiza un bubble sort para elimnar el espacio en blanco y disminuye en 1 el numero de participantes
                    for(int j = i; j < NumeroParticipantes; j++)
                    {
                        serverIP[j] = serverIP[j++];
                        serverPort[j] = serverPort[j++];
                    }
                }
            }
            NumeroParticipantes--;
            textBox1.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            String s = "";
            for(int i = 0; i < connected; i++)
            {
                s += "\n"+ ListConnected[i];
            }
            MessageBox.Show(s);
        }

        public void VerificarListConnected(String s)
        {
            int a = 0;
            for (int i = 0; i < connected; i++)
            {
                if (ListConnected[i] == s)
                {
                    a = 1;
                }
            }
            if (a == 0)
            {
                ListConnected[connected] = s;
                connected++;
            }
        }
    }
}
