#pragma once
#include <conio.h>
#include <stdio.h>
#include <iostream>
#include <windows.h>
using namespace std;

class Imprmir
{
public:

	Imprmir(void)
	{
	}

	virtual ~Imprmir(void)
	{
	}
};
void ImprimirPantalla(){
	HANDLE hout= GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hout,15);
	cout<<"______________________________________________________________________________\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|_________________________|_________________________|_________________________|\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|                         |                         |                         |\n";
	cout<<"|_________________________|_________________________|_________________________|\n";
	cout<<"|Comando:                                                                     |\n";
	cout<<"|_____________________________________________________________________________|\n";
	cout<<"|Output:                                                                      |\n";
	cout<<"|_____________________________________________________________________________|\n";
}