#include "StdAfx.h"
#include "Blink.h"

Blink::Blink(void)
{
}

Blink::~Blink(void)
{
}
