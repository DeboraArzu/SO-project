﻿namespace Database
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnInsert = new System.Windows.Forms.Button();
            this.tbQuantity = new System.Windows.Forms.TextBox();
            this.tbOrigen = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.sysDataSet = new Database.sysDataSet();
            this.listatransaccionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lista_transaccionTableAdapter = new Database.sysDataSetTableAdapters.lista_transaccionTableAdapter();
            this.sysDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tbDestino = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.sysDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.listatransaccionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sysDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnInsert
            // 
            this.btnInsert.Location = new System.Drawing.Point(74, 69);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(165, 23);
            this.btnInsert.TabIndex = 0;
            this.btnInsert.Text = "Insert";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbQuantity
            // 
            this.tbQuantity.Location = new System.Drawing.Point(74, 44);
            this.tbQuantity.Name = "tbQuantity";
            this.tbQuantity.Size = new System.Drawing.Size(51, 20);
            this.tbQuantity.TabIndex = 1;
            // 
            // tbOrigen
            // 
            this.tbOrigen.Location = new System.Drawing.Point(131, 44);
            this.tbOrigen.Name = "tbOrigen";
            this.tbOrigen.Size = new System.Drawing.Size(51, 20);
            this.tbOrigen.TabIndex = 2;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(74, 98);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(165, 23);
            this.button2.TabIndex = 3;
            this.button2.Text = "Delete";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // sysDataSet
            // 
            this.sysDataSet.DataSetName = "sysDataSet";
            this.sysDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // listatransaccionBindingSource
            // 
            this.listatransaccionBindingSource.DataMember = "lista_transaccion";
            this.listatransaccionBindingSource.DataSource = this.sysDataSet;
            // 
            // lista_transaccionTableAdapter
            // 
            this.lista_transaccionTableAdapter.ClearBeforeFill = true;
            // 
            // sysDataSetBindingSource
            // 
            this.sysDataSetBindingSource.DataSource = this.sysDataSet;
            this.sysDataSetBindingSource.Position = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(39, 178);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(493, 201);
            this.dataGridView1.TabIndex = 4;
            // 
            // tbDestino
            // 
            this.tbDestino.Location = new System.Drawing.Point(188, 44);
            this.tbDestino.Name = "tbDestino";
            this.tbDestino.Size = new System.Drawing.Size(51, 20);
            this.tbDestino.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(567, 410);
            this.Controls.Add(this.tbDestino);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.tbOrigen);
            this.Controls.Add(this.tbQuantity);
            this.Controls.Add(this.btnInsert);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sysDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.listatransaccionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sysDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.TextBox tbQuantity;
        private System.Windows.Forms.TextBox tbOrigen;
        private System.Windows.Forms.Button button2;
        private sysDataSet sysDataSet;
        private System.Windows.Forms.BindingSource listatransaccionBindingSource;
        private sysDataSetTableAdapters.lista_transaccionTableAdapter lista_transaccionTableAdapter;
        private System.Windows.Forms.BindingSource sysDataSetBindingSource;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox tbDestino;
    }
}

