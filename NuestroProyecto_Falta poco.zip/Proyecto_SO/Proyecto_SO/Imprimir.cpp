#include "StdAfx.h"
#include "Imprimir.h"

Imprimir::Imprimir(void)
{
}

Imprimir::~Imprimir(void)
{
}
