#pragma once
#include "stdafx.h"
#include "Kernel.h"
#include <iostream>
#include <stdlib.h>
#include <windows.h>
#include <sstream>
#include <stdio.h>
#include <time.h>
#include <string>
#include "imprimir.h"
using namespace std;

void GotoxyMouse(int x, int y);
int exitPro=0;
int direccion[6];
int EnProceso[6];
int CoorX=15;
int CoorY=33;
//son las variables que obtienen la hora actual.
clock_t t_ini, t_fin;
double secs=0;
double TiempoProceso [6]; // tiempo que ha estado ejecutando el proceso
double TiempoParaProceso[6];// tiempo indicado para cada proceso

//almacenan las coordenadas de cada punto 
int MemoriaProceso1 [2][500];
int MemoriaProceso2 [2][500];
int MemoriaProceso3 [2][500];
int MemoriaProceso4 [2][500];
int MemoriaProceso5 [2][500];
int MemoriaProceso6 [2][500];
//Verifica que ventana esta seleccionada
int VentanaSeleccionada=0;
//temporal
int window=0;
int quantum=0;
int stat=0;
int iclic=0;
string estatusfinal="";
string sclic="";
//su funcion es exclusivamente para el for 

// almacena los tiempos o quantum asignado a cada cada proceso

int RecorrerCadena=0;
int NumeroEspacios=0;

int EspaciosContinuos=0;
int ComandoEnNumero=0;
int VentanaEnNumero=0;
int TiempoEnNumero=0;

//string que serviran para obtener los comandos, ventanas y tiempo
string ComandoIntro="";
string VentanaIntro="";
string TiempoIntro="";
string a = "";
string b = "";

//Estos deben de ser eliminados cuando se unifique el trabajo
bool V1=false;
bool V2=false;
bool V3=false;
bool V4=false;
bool V5=false;
bool V6=false;

//Variable el cual almacena caracter por caracter 
char Comandos[12];
int NumComando=0;

//clase kernel
Kernel *kernel = new Kernel();

class Mouse
{
public:

	Mouse(void)
	{
	}

	virtual ~Mouse(void)
	{
	}
};
void InicializarContador(){
	for (int i=0;i<6;i++){
		direccion[i]=0;
		EnProceso[i]=0;
		TiempoProceso[i]=0;
		TiempoParaProceso[i]=10;
	}
}



void CompararTexto(){
	if(ComandoIntro.compare("add")==0){
		ComandoEnNumero=1;
	}
	else{
		if(ComandoIntro.compare("pause")==0){
			ComandoEnNumero=2;
		}
		else{
			if(ComandoIntro.compare("remove")==0){
				ComandoEnNumero=3;
			}
			else{
				if(ComandoIntro.compare("clear")==0){
					ComandoEnNumero=4;
				}
				else{
					if(ComandoIntro.compare("quantum")==0){
						ComandoEnNumero=5;
					}
					else{
						if(ComandoIntro.compare("stats")==0){
							ComandoEnNumero=6;
						}
						else{
							if(ComandoIntro.compare("exit")==0){
								ComandoEnNumero=7;
							}
							else
							{
								ComandoEnNumero=8;
							}
						}
					}
				}
			}
		}
	}
}
void LimpiarCadena(){
	for(int i=0;i<12;i++){
		Comandos[i]=0;
	}
}

void ActivarVentana(){
	if(VentanaIntro.compare("1")==0){
		V1 = true;
	}
	else{
		if(VentanaIntro.compare("2")==0){
			V2 = true;
		}
		else{
			if(VentanaIntro.compare("3")==0){
				V3 = true;
			}
			else{
				if(VentanaIntro.compare("4")==0){
					V4 = true;
				}
				else{
					if(VentanaIntro.compare("5")==0){
						V5 = true;
					}
					else{
						if(VentanaIntro.compare("6")==0){
							V6 = true;
						}
					}
				}
			}
		}
	}
}
void DesactivarVentana(){
	if(VentanaIntro.compare("1")==0){
		V1 = false;
	}
	else{
		if(VentanaIntro.compare("2")==0){
			V2 = false;
		}
		else{
			if(VentanaIntro.compare("3")==0){
				V3 = false;
			}
			else{
				if(VentanaIntro.compare("4")==0){
					V4 = false;
				}
				else{
					if(VentanaIntro.compare("5")==0){
						V5 = false;
					}
					else{
						if(VentanaIntro.compare("6")==0){
							V6 = false;
						}
					}
				}
			}
		}
	}
}

void EliminarMemoriaProceso(int NumProceso){
	switch (NumProceso){
		case 1:
			/*			for(int i=0;i<direccion[0];i++){
			MemoriaProceso1[0][i]=0;				
			MemoriaProceso1[1][i]=0;
			}*/
			direccion[0]=0;
			EnProceso[0]=0;
			break;
		case 2:
			/*for(int i=0;i<direccion[0];i++){
			MemoriaProceso2[0][i]=0;				
			MemoriaProceso2[1][i]=0;
			}*/
			direccion[1]=0;
			EnProceso[1]=0;
			break;
		case 3:
			/*for(int i=0;i<direccion[0];i++){
			MemoriaProceso3[0][i]=0;				
			MemoriaProceso3[1][i]=0;
			}*/
			direccion[2]=0;
			EnProceso[2]=0;
			break;
		case 4:
			/*for(int i=0;i<direccion[0];i++){
			MemoriaProceso4[0][i]=0;				
			MemoriaProceso4[1][i]=0;
			}*/
			direccion[3]=0;
			EnProceso[3]=0;
			break;
		case 5:
			/*for(int i=0;i<direccion[0];i++){
			MemoriaProceso5[0][i]=0;				
			MemoriaProceso5[1][i]=0;
			}*/
			direccion[4]=0;
			EnProceso[4]=0;
			break;
		case 6:
			/*for(int i=0;i<direccion[0];i++){
			MemoriaProceso6[0][i]=0;				
			MemoriaProceso6[1][i]=0;
			}*/
			direccion[5]=0;
			EnProceso[5]=0;
			break;
	}
	system("cls");
	ImprimirPantalla();
}
void status(){
	//se obtiene el numero del status
	stat = kernel->getstatus(window);
	sclic = kernel->getsclics(window);
	istringstream(sclic) >> iclic;
	switch(stat){
		estatusfinal = "";
		case 1:{
			//running
			//estatusfinal = "Running, numero de procesos " + direccion[window-1] + "Tiempo de ejecucion " + TiempoProceso[0];
			gotoxy(15,38);
			printf("Running, numero de procesos: %i  Tiempo de ejecucion %g",direccion[window-1],TiempoProceso[0]);
			gotoxy(CoorX, CoorY);
			break;}
		case 2:{
			//Blocked
			//estatusfinal = "Running, numero de procesos " + direccion[window-1] + "Tiempo de ejecucion " + TiempoProceso[0];
			gotoxy(15,38);
			printf("Bloqueado, numero de procesos: %i  Tiempo de ejecucion %g",direccion[window-1],TiempoProceso[1]);
			gotoxy(CoorX, CoorY);
			break;}
		case 3:{
			//Ready
			//estatusfinal = "Running, numero de procesos " + direccion[window-1] + "Tiempo de ejecucion " + TiempoProceso[0];
			gotoxy(15,38);
			printf("Ready, numero de procesos: %i  Tiempo de ejecucion %g",direccion[window-1],TiempoProceso[2]);
			gotoxy(CoorX, CoorY);
			break;}
		case 4:{
			//rSuspended
			//estatusfinal = "Running, numero de procesos " + direccion[window-1] + "Tiempo de ejecucion " + TiempoProceso[0];
			gotoxy(15,38);
			printf("Suspended, numero de procesos: %i  Tiempo de ejecucion %g",direccion[window-1],TiempoProceso[3]);
			gotoxy(CoorX, CoorY);
			break;}
		case 5:{
			//Waiting
			//estatusfinal = "Running, numero de procesos " + direccion[window-1] + "Tiempo de ejecucion " + TiempoProceso[0];
			gotoxy(15,38);
			printf("Waiting, numero de procesos: %i  Tiempo de ejecucion %g",direccion[window-1],TiempoProceso[4]);
			gotoxy(CoorX, CoorY);
			break;}
		case 6:{
			//Done
			//estatusfinal = "Running, numero de procesos " + direccion[window-1] + "Tiempo de ejecucion " + TiempoProceso[0];
			gotoxy(15,38);
			printf("Done, numero de procesos: %i  Tiempo de ejecucion %g",direccion[window-1],TiempoProceso[5]);
			gotoxy(CoorX, CoorY);
			break;}
	}

}
void coorMouse()
{
	HANDLE hout= GetStdHandle(STD_OUTPUT_HANDLE);
	HANDLE hin = GetStdHandle(STD_INPUT_HANDLE);
	INPUT_RECORD InputRecord;
	DWORD Events;
	COORD coord;
	CONSOLE_CURSOR_INFO cci;
	cci.dwSize = 25;
	cci.bVisible = FALSE;
	SetConsoleCursorInfo(hout, &cci);
	SetConsoleMode(hin, ENABLE_PROCESSED_INPUT | ENABLE_MOUSE_INPUT);

	if(WaitForSingleObject(hin,10)==WAIT_OBJECT_0){
		ReadConsoleInput(hin, &InputRecord, 1, &Events);// evento lee lo que esta en ejecucion en ese momento
		if(InputRecord.Event.KeyEvent.uChar.AsciiChar!=0||InputRecord.Event.MouseEvent.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED){
			switch ( InputRecord.EventType ){
case KEY_EVENT: // keyboard input 
	switch (InputRecord.Event.KeyEvent.wVirtualKeyCode)
	{
	case 32:
		// barra espaciadora
		gotoxy(CoorX, CoorY);
		cout<<" ";
		CoorX++;
		Comandos[NumComando]=Comandos[NumComando]+InputRecord.Event.KeyEvent.uChar.AsciiChar;
		NumComando++;
		//EspaciosCadena[NumeroEspacios]=NumComando;
		Sleep(100);
		break;
	case 8:
		/*En caso que se hayan equivocado al teclear o paso una letra de mas*/
		if(CoorX>15){
			CoorX=CoorX-1;
			gotoxy(CoorX,CoorY);
			cout<<" ";
			gotoxy(CoorX,CoorY);
			NumComando--;
			Comandos[NumComando]=0;
			Sleep(100);
		}
		break;
	case 13:
		/*Enter
		Al oprimir enter se deberia de comenzar a validar si existe la accion que solicita*/
		CoorX=15;								
		gotoxy(CoorX, CoorY);
		cout<<"                           ";
		gotoxy(15,35);
		cout<<"                           ";
		gotoxy(CoorX, CoorY);


		//Aqui deberia de escribir el codio para validar el codigo o texto escrito.
		for (RecorrerCadena=0;RecorrerCadena<NumComando;RecorrerCadena++){
			if(Comandos[RecorrerCadena]==32){
				if(EspaciosContinuos==0){
					NumeroEspacios++;
				}
				EspaciosContinuos=1;
			}
			else{
				EspaciosContinuos=0;
				if(NumeroEspacios==0){
					//se obtiene el numero de ventana
					ComandoIntro+= Comandos[RecorrerCadena];
				}
				else{
					if(NumeroEspacios==1){
						//se obtiene el numero de la ventana
						VentanaIntro+=Comandos[RecorrerCadena];
					}
					else{
						if(NumeroEspacios>1){
							//se obtiene el numero de quantum
							TiempoIntro+=Comandos[RecorrerCadena];
						}
					}
				}
			}		
		}
		LimpiarCadena();
		NumComando=0;
		CompararTexto();
		ComandoIntro="";
		NumeroEspacios = 0;

		switch (ComandoEnNumero){
	case 1: //add
		gotoxy(15,35);
		cout<<"Comando           ";
		gotoxy(CoorX, CoorY);
		//codigo agregar proceso
		ActivarVentana();
		istringstream(VentanaIntro) >> window;
		kernel->addProcess(window);
		VentanaIntro="";
		break;
	case 2: //pause
		gotoxy(15,35);
		cout<<"Comando           ";
		gotoxy(CoorX, CoorY);
		//pausar el proceso
		istringstream(VentanaIntro) >> window;
		kernel->Pause(window);
		VentanaIntro="";
		break;
	case 3: //remove
		gotoxy(15,35);
		cout<<"Comando             ";
		gotoxy(CoorX, CoorY);
		//matar el proceso
		istringstream(VentanaIntro) >> window;
		//validar la ventana como false
		DesactivarVentana();
		EliminarMemoriaProceso(window);
		kernel->killProcessById(window);
		VentanaIntro="";
		break;
	case 4: //clear
		gotoxy(15,35);
		cout<<"Comando                   ";
		gotoxy(CoorX, CoorY);
		//limpiar la ventana.
		istringstream(VentanaIntro) >> window;
		EliminarMemoriaProceso(window);
		kernel->EliminarClics(window);
		VentanaIntro="";
		break;
	case 5: //quantum
		gotoxy(15,35);
		cout<<"Comando                  ";
		gotoxy(CoorX, CoorY);
		//cambiar el quantum
		istringstream(VentanaIntro) >> window;
		istringstream(TiempoIntro) >> quantum;
		kernel->changequantum(window, quantum);
		VentanaIntro="";
		TiempoIntro="";
		break;
	case 6: //stats
		//mostrar las estadisticas
		istringstream(VentanaIntro) >> window;
		status();
		VentanaIntro="";
		break;
	case 7: //exit
		gotoxy(15,35);
		cout<<"Adios estimado usuario ";
		cin.ignore();
		exitPro=1;
		break;
	default:
		gotoxy(15,35);
		cout<<"Comando                   ";
		gotoxy(CoorX, CoorY);
		break;
		}
		break;
	default:
		Sleep(100);
		if(NumComando==12){
			gotoxy(15,35);
			cout<<"   ";
			gotoxy(15,35);
			cout<<"Limite de caracteres alcanzado";
		}
		else{
			if((InputRecord.Event.KeyEvent.wVirtualKeyCode>64&&InputRecord.Event.KeyEvent.wVirtualKeyCode<91)&&NumComando<12){
				SetConsoleTextAttribute(hout,15);
				gotoxy(CoorX,CoorY);
				cout<<InputRecord.Event.KeyEvent.uChar.AsciiChar;
				Comandos[NumComando]=InputRecord.Event.KeyEvent.uChar.AsciiChar;
				CoorX++;
				NumComando++;
			}
			else{
				if((InputRecord.Event.KeyEvent.wVirtualKeyCode>96||InputRecord.Event.KeyEvent.wVirtualKeyCode<123)&&NumComando<12){
					SetConsoleTextAttribute(hout,15);
					gotoxy(CoorX,CoorY);
					cout<<InputRecord.Event.KeyEvent.uChar.AsciiChar;
					Comandos[NumComando]=InputRecord.Event.KeyEvent.uChar.AsciiChar;
					CoorX++;
					NumComando++;
				}
				else{
					if((InputRecord.Event.KeyEvent.wVirtualKeyCode==32)&&NumComando<12){
						SetConsoleTextAttribute(hout,15);
						gotoxy(CoorX,CoorY);
						cout<<InputRecord.Event.KeyEvent.uChar.AsciiChar;
						Comandos[NumComando]=InputRecord.Event.KeyEvent.uChar.AsciiChar;
						CoorX++;
						NumComando++;
					}
					else{
						if((InputRecord.Event.KeyEvent.wVirtualKeyCode>47&&InputRecord.Event.KeyEvent.wVirtualKeyCode<58)&&NumComando<12){
							SetConsoleTextAttribute(hout,15);
							gotoxy(CoorX,CoorY);
							cout<<InputRecord.Event.KeyEvent.uChar.AsciiChar;
							Comandos[NumComando]=InputRecord.Event.KeyEvent.uChar.AsciiChar;
							CoorX++;
							NumComando++;
						}
					}
				}
			}
		}
		break;
	}//switch
	//---------------------------------------------------------------------------------
	break; 

case MOUSE_EVENT: // mouse input 

	if(InputRecord.Event.MouseEvent.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED)
	{
		coord.X = InputRecord.Event.MouseEvent.dwMousePosition.X;
		coord.Y = InputRecord.Event.MouseEvent.dwMousePosition.Y;
		SetConsoleCursorPosition(hout,coord);
		SetConsoleTextAttribute(hout,rand() %7+9);/*le da el color que el random indica*/

		if(coord.X>0&&coord.X<26){
			if(coord.Y>0&&coord.Y<16){
				if(V1==true){
					if(VentanaSeleccionada==1){
						//Proceso 1
						MemoriaProceso1[0][direccion[0]]=InputRecord.Event.MouseEvent.dwMousePosition.X;
						MemoriaProceso1[1][direccion[0]]=InputRecord.Event.MouseEvent.dwMousePosition.Y;
						cout<<".";
						//agregar clics al proceso
						direccion[0]++;
						kernel->AgregarClics(1,direccion[0]);
					}
					else{
						VentanaSeleccionada=1;
					}
				}
				else{
					gotoxy(15,35);
					cout<<"                               ";
					gotoxy(15,35);
					cout<<"No existe el proceso           ";
				}									
			}
			else{
				if(coord.Y>16&&coord.Y<32){
					if(V4==true){
						if(VentanaSeleccionada==4){
							//Proceso 4
							MemoriaProceso4[0][direccion[3]]=InputRecord.Event.MouseEvent.dwMousePosition.X;
							MemoriaProceso4[1][direccion[3]]=InputRecord.Event.MouseEvent.dwMousePosition.Y;
							cout<<".";
							//agregar clics al proceso
							direccion[3]++;
							kernel->AgregarClics(4,direccion[3]);
						}
						else{
							VentanaSeleccionada=4;
						}
					}
					else{
						gotoxy(15,35);
						cout<<"                                   ";
						gotoxy(15,35);
						cout<<"No existe el proceso            ";
					}
				}
			}
		}
		else{
			if(coord.X>26&&coord.X<52){
				if(coord.Y>0&&coord.Y<16){
					if(V2==true){
						if(VentanaSeleccionada==2){
							//Proceso 2
							MemoriaProceso2[0][direccion[1]]=InputRecord.Event.MouseEvent.dwMousePosition.X;
							MemoriaProceso2[1][direccion[1]]=InputRecord.Event.MouseEvent.dwMousePosition.Y;
							cout<<".";
							//agregar clics al proceso
							direccion[1]++;
							kernel->AgregarClics(2,direccion[1]);
						}
						else{
							VentanaSeleccionada=2;
						}
					}
					else{
						gotoxy(15,35);
						cout<<"                                        ";
						gotoxy(15,35);
						cout<<"No existe el proceso";
					}
				}
				else{
					//area de proceso 5
					if(coord.Y>16&&coord.Y<32){
						if(V5==true){
							if(VentanaSeleccionada==5){
								MemoriaProceso5[0][direccion[4]]=InputRecord.Event.MouseEvent.dwMousePosition.X;
								MemoriaProceso5[1][direccion[4]]=InputRecord.Event.MouseEvent.dwMousePosition.Y;
								cout<<".";
								//agregar clics al proceso
								direccion[4]++;
								kernel->AgregarClics(5,direccion[4]);
							}
							else{
								VentanaSeleccionada=5;
							}
						}
						else{
							gotoxy(15,35);
							cout<<"                                           ";
							gotoxy(15,35);
							cout<<"No existe el proceso                     ";
						}
					}
				}
			}	
			else{
				if(coord.X>52&&coord.X<78){
					if(coord.Y>0&&coord.Y<16){
						//area de proceso 3
						if(V3==true){
							if(VentanaSeleccionada==3){
								MemoriaProceso3[0][direccion[2]]=InputRecord.Event.MouseEvent.dwMousePosition.X;
								MemoriaProceso3[1][direccion[2]]=InputRecord.Event.MouseEvent.dwMousePosition.Y;
								cout<<".";
								//agregar clics al proceso
								direccion[2]++;
								kernel->AgregarClics(3,direccion[2]);
							}
							else{
								VentanaSeleccionada=3;
							}
						}
						else{
							gotoxy(15,35);
							cout<<"                               ";
							gotoxy(15,35);
							cout<<"No existe el proceso             ";
						}
					}
					else{
						if(coord.Y>16&&coord.Y<32){
							//area de proceso 6
							if(V6==true){
								if(VentanaSeleccionada==6){
									MemoriaProceso6[0][direccion[5]]=InputRecord.Event.MouseEvent.dwMousePosition.X;
									MemoriaProceso6[1][direccion[5]]=InputRecord.Event.MouseEvent.dwMousePosition.Y;
									cout<<".";
									//agregar clics al proceso
									direccion[5]++;
									kernel->AgregarClics(6, direccion[5]);
								}
								else{
									VentanaSeleccionada=6;
								}
							}
							else{
								gotoxy(15,35);
								cout<<"                               ";
								gotoxy(15,35);
								cout<<"No existe el proceso           ";
							}
						}
					}
				}	
			}
		}
	}// mouse 
	break; 
			}
			FlushConsoleInputBuffer(hin);
		}
	}
	//cout<<"\n";
	return;
}
void GotoxyMouse(int x, int y){
	COORD coord;
	coord.X = x; coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
	return;
}
//*****************************************************************************
//     colors:
//     0 = Black
//     1 = Blue
//     2 = Green
//     3 = Cyan
//     4 = Red
//     5 = Magenta
//     6 = Yellow
//     7 = LightGray
//     8 = DarkGray
//     9 = LightBlue
//     10 = LightGreen
//     11 = LightCyan
//     12 = LightRed
//     13 = LightMagenta
//     14 = LightYellow
//     15 = White
//*****************************************************************************
int ImprimirPuntos(){
	HANDLE hout= GetStdHandle(STD_OUTPUT_HANDLE);
	//imprime los puntos del proceso 1
	while (exitPro==0){/*aqui colocar la condiciona para que cuando se elimine un proceso se salga del bucle y limpie la pantalla*/
		coorMouse();
		if(direccion[0]!=0){
			t_ini=clock();
			for (int i=EnProceso[0];i<direccion[0];i++){
				coorMouse();
				SetConsoleTextAttribute(hout,rand() %7+9);
				gotoxy(MemoriaProceso1[0][i],MemoriaProceso1[1][i]);
				cout<<".";
				EnProceso[0]++;
				t_fin=clock();
				secs += (double)(t_fin - t_ini)/CLOCKS_PER_SEC;
				if(TiempoParaProceso[0]<=(secs*1000))
				{
					i=direccion[0];
				}
				if(EnProceso[0]==direccion[0])
					EnProceso[0]=0;
			}
			TiempoProceso[0]+=secs*1000;
			secs=0;
		}
		//imprime los puntos del proceso 2
		if(direccion[1]!=0){
			t_ini=clock();
			for (int i=EnProceso[1];i<direccion[1];i++){
				coorMouse();
				SetConsoleTextAttribute(hout,rand() %7+9);
				gotoxy(MemoriaProceso2[0][i],MemoriaProceso2[1][i]);
				cout<<".";
				EnProceso[1]++;
				t_fin=clock();
				secs += (double)(t_fin - t_ini)/CLOCKS_PER_SEC;
				if(TiempoParaProceso[1]<=(secs*1000))
				{
					i=direccion[1];
				}
				if(EnProceso[1]==direccion[1])
					EnProceso[1]=0;
			}
			TiempoProceso[1]+=secs*1000;
			secs=0;
		}
		//imprime los puntos del proceso 3
		if(direccion[2]!=0){
			t_ini=clock();
			for (int i=EnProceso[2];i<direccion[2];i++){
				coorMouse();
				SetConsoleTextAttribute(hout,rand() %7+9);
				gotoxy(MemoriaProceso3[0][i],MemoriaProceso3[1][i]);
				cout<<".";
				EnProceso[2]++;
				t_fin=clock();
				secs += (double)(t_fin - t_ini)/CLOCKS_PER_SEC;
				if(TiempoParaProceso[2]<=(secs*1000))
				{
					i=direccion[2];
				}
				if(EnProceso[2]==direccion[2])
					EnProceso[2]=0;
			}
			TiempoProceso[2]+=secs*1000;
			secs=0;
		}
		//imprime los puntos del proceso 4
		if(direccion[3]!=0){
			t_ini=clock();
			for (int i=EnProceso[3];i<direccion[3];i++){
				coorMouse();
				SetConsoleTextAttribute(hout,rand() %7+9);
				gotoxy(MemoriaProceso4[0][i],MemoriaProceso4[1][i]);
				cout<<".";
				EnProceso[3]++;
				t_fin=clock();
				secs += (double)(t_fin - t_ini)/CLOCKS_PER_SEC;
				if(TiempoParaProceso[3]<=(secs*1000))
				{
					i=direccion[3];
				}
				if(EnProceso[3]==direccion[3])
					EnProceso[3]=0;
			}
			TiempoProceso[3]+=secs*1000;
			secs=0;
		}
		//imprime los puntos del proceso 5
		if(direccion[4]!=0){
			t_ini=clock();
			for (int i=EnProceso[4];i<direccion[4];i++){
				coorMouse();
				SetConsoleTextAttribute(hout,rand() %7+9);
				gotoxy(MemoriaProceso5[0][i],MemoriaProceso5[1][i]);
				cout<<".";
				EnProceso[4]++;
				t_fin=clock();
				secs += (double)(t_fin - t_ini)/CLOCKS_PER_SEC;
				if(TiempoParaProceso[4]<=(secs*1000))
				{
					i=direccion[4];
				}
				if(EnProceso[4]==direccion[4])
					EnProceso[4]=0;
			}
			TiempoProceso[4]+=secs*1000;
			secs=0;
		}
		//imprime los puntos del proceso 6
		if(direccion[5]!=0){
			t_ini=clock();
			for (int i=EnProceso[5];i<direccion[5];i++){
				SetConsoleTextAttribute(hout,rand() %7+9);
				gotoxy(MemoriaProceso6[0][i],MemoriaProceso6[1][i]);
				cout<<".";
				EnProceso[5]++;
				t_fin=clock();
				secs += (double)(t_fin - t_ini)/CLOCKS_PER_SEC;
				if(TiempoParaProceso[5]<=(secs*1000))
				{
					i=direccion[5];
				}
				if(EnProceso[5]==direccion[5])
					EnProceso[5]=0;
			}
			TiempoProceso[5]+=secs*1000;
			secs=0;
		}
	}
	return exitPro;
}