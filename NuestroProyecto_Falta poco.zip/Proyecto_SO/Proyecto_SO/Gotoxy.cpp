#include "StdAfx.h"
#include "Gotoxy.h"

Gotoxy::Gotoxy(void)
{
}

Gotoxy::~Gotoxy(void)
{
}
