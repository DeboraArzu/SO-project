#include "StdAfx.h"
#include "ImplementacionMouse.h"

ImplementacionMouse::ImplementacionMouse(void)
{
}

ImplementacionMouse::~ImplementacionMouse(void)
{
}
