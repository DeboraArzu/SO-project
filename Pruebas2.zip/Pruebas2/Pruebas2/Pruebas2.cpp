// Pruebas2.cpp : Defines the entry point for the console application.
//
#include <dos.h>
#include <ctype.h>
#include <graphics.h>
#include <stdafx.h>
#include <stdlib.h>
#include <conio.h>
#include <stdio.h>
#include <iostream>
#include <windows.h>
#include "Gotoxy.h"
#include "mouse.h"
#include "Imprmir.h"
using namespace std;

//void gotoxy(int x, int y){
//	HANDLE hcon;
//	hcon=GetStdHandle(STD_OUTPUT_HANDLE);
//	COORD dwPos;
//	dwPos.X=x;
//	dwPos.Y=y;8
//	SetConsoleCursorPosition(hcon,dwPos);
//}


int _tmain(int argc, _TCHAR* argv[])
{
	InicializarContador();
	char a;
	while (1){
		system("cls");
		ImprimirPantalla();
		ImprimirPuntos();
	}
	return 0;
}